Put here tests, ensuring that the v's parser errors for certain situations.
