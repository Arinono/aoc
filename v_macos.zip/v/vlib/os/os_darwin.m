/*
NSString* nsstring(string s);

void darwin_log(string s) {
	NSLog(nsstring(s));
}
*/
