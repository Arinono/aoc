In this directory:
```
v run checks.v
```

