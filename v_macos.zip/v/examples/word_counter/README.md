```
usage: word_counter [text_file]
using cinderella.txt
a => 25
able => 2
after => 1
afterwards => 1
again => 10
against => 2
all => 12
allow => 1
allowed => 2
along => 1
also => 2
always => 2
an => 4
and => 140
anew => 1
anger => 1
another => 2
answered => 1
any => 1
anyone => 2
...
```
