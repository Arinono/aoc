@include './header.md'

This is the main content:
-------------------------
@content
-------------------------

@include './footer.md'
