
struct Abc {
   char *char_pointer_field;
};
