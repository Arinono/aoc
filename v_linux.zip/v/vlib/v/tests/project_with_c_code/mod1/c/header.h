#ifndef ADD_H
#define ADD_H

int cadd(int a, int b);

struct MyStruct {
    int UppercaseField;
};

#endif
