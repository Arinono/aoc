This folder contains bn.h and bn.c files
from https://github.com/kokke/tiny-bignum-c
