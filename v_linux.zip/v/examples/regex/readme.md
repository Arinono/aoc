# regex

There are 2 ways to do regex:
a) using the native module called `regex`
b) using an exteranl module called `pcre`, which wraps the C library pcre.
NB: you need to first do: `v install pcre`, for the `pcre` module to work.

You can find examples of both in this directory.
